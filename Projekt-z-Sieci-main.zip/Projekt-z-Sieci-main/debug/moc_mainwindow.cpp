/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN10MainWindowE = QtMocHelpers::stringData(
    "MainWindow",
    "on_Start_clicked",
    "",
    "on_Stop_clicked",
    "on_UstawieniaObiektuARX_clicked",
    "PokazWykres",
    "Blad",
    "on_Reset_clicked",
    "on_Zapisz_clicked",
    "on_Wczytaj_clicked",
    "bladUstawien",
    "on_Amplituda_editingFinished",
    "on_Wypelnienie_editingFinished",
    "on_CzasAktywacji_editingFinished",
    "on_Okres_editingFinished",
    "on_Wzmocnienie_editingFinished",
    "on_StalaI_editingFinished",
    "on_StalaD_editingFinished",
    "on_Interwal_editingFinished",
    "on_RodzajSygnalu_clicked",
    "on_RodzajSygnalu_triggered",
    "QAction*",
    "arg1",
    "on_Sposob_clicked",
    "on_Sposob_triggered"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN10MainWindowE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x08,    1 /* Private */,
       3,    0,  141,    2, 0x08,    2 /* Private */,
       4,    0,  142,    2, 0x08,    3 /* Private */,
       5,    0,  143,    2, 0x08,    4 /* Private */,
       6,    0,  144,    2, 0x08,    5 /* Private */,
       7,    0,  145,    2, 0x08,    6 /* Private */,
       8,    0,  146,    2, 0x08,    7 /* Private */,
       9,    0,  147,    2, 0x08,    8 /* Private */,
      10,    0,  148,    2, 0x08,    9 /* Private */,
      11,    0,  149,    2, 0x08,   10 /* Private */,
      12,    0,  150,    2, 0x08,   11 /* Private */,
      13,    0,  151,    2, 0x08,   12 /* Private */,
      14,    0,  152,    2, 0x08,   13 /* Private */,
      15,    0,  153,    2, 0x08,   14 /* Private */,
      16,    0,  154,    2, 0x08,   15 /* Private */,
      17,    0,  155,    2, 0x08,   16 /* Private */,
      18,    0,  156,    2, 0x08,   17 /* Private */,
      19,    0,  157,    2, 0x08,   18 /* Private */,
      20,    1,  158,    2, 0x08,   19 /* Private */,
      23,    0,  161,    2, 0x08,   21 /* Private */,
      24,    1,  162,    2, 0x08,   22 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 21,   22,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_ZN10MainWindowE.offsetsAndSizes,
    qt_meta_data_ZN10MainWindowE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN10MainWindowE_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_Start_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Stop_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_UstawieniaObiektuARX_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'PokazWykres'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'Blad'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Reset_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Zapisz_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Wczytaj_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bladUstawien'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Amplituda_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Wypelnienie_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_CzasAktywacji_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Okres_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Wzmocnienie_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_StalaI_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_StalaD_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Interwal_editingFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_RodzajSygnalu_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_RodzajSygnalu_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>,
        // method 'on_Sposob_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Sposob_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->on_Start_clicked(); break;
        case 1: _t->on_Stop_clicked(); break;
        case 2: _t->on_UstawieniaObiektuARX_clicked(); break;
        case 3: _t->PokazWykres(); break;
        case 4: _t->Blad(); break;
        case 5: _t->on_Reset_clicked(); break;
        case 6: _t->on_Zapisz_clicked(); break;
        case 7: _t->on_Wczytaj_clicked(); break;
        case 8: _t->bladUstawien(); break;
        case 9: _t->on_Amplituda_editingFinished(); break;
        case 10: _t->on_Wypelnienie_editingFinished(); break;
        case 11: _t->on_CzasAktywacji_editingFinished(); break;
        case 12: _t->on_Okres_editingFinished(); break;
        case 13: _t->on_Wzmocnienie_editingFinished(); break;
        case 14: _t->on_StalaI_editingFinished(); break;
        case 15: _t->on_StalaD_editingFinished(); break;
        case 16: _t->on_Interwal_editingFinished(); break;
        case 17: _t->on_RodzajSygnalu_clicked(); break;
        case 18: _t->on_RodzajSygnalu_triggered((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        case 19: _t->on_Sposob_clicked(); break;
        case 20: _t->on_Sposob_triggered((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN10MainWindowE.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
